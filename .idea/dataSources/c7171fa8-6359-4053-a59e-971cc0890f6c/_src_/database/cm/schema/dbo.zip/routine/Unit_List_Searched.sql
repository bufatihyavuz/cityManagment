create procedure Unit_List_Searched
(
@SayfaNo int,
@SayfabasinaSayi int,
@searchKey nvarchar(MAX)
)
AS
BEGIN

SELECT * 
FROM Unit u  
join Floor as  f on u.floorId=f.id 
join Member as m on u.memberId=m.id
join UnitType as ut on u.unitTypeId = ut.id
where u.unitNo LIKE '%' + @searchKey + '%' or f.floorNo LIKE '%' + @searchKey + '%' or 
m.name LIKE '%' + @searchKey + '%' or ut.unitType LIKE '%' + @searchKey + '%'

ORDER BY u.id

OFFSET ((@SayfaNo - 1) * @SayfabasinaSayi) ROWS

FETCH NEXT @SayfabasinaSayi ROWS ONLY;

END
GO
