create procedure getUnitFloor (
@unitId int
)
as 
begin
select * from Floor where apartmentId =  ( select f.apartmentId from Floor f where id =(select a.floorId from unit a where  id = @unitId ))
end
GO
