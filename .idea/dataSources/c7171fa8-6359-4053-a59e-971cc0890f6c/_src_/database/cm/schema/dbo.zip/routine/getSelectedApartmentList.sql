create procedure getSelectedApartmentList(
@buildingsId Integer 
)
as begin
select * from Apartment a  where a.buildingsId=@buildingsId
end
GO
