create procedure Unit_List_Search_Count
(
@searchKey nvarchar(MAX)
)
AS
BEGIN

SELECT count(*) 

FROM Unit where unitNo LIKE '%' + @searchKey + '%' or floorId LIKE '%' + @searchKey + '%' or 
memberId LIKE '%' + @searchKey + '%' or unitTypeId LIKE '%' + @searchKey + '%'

END

GO
