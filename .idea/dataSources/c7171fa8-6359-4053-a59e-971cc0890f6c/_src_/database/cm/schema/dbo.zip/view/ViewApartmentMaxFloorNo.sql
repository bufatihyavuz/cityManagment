create view ViewApartmentMaxFloorNo as
SELECT a.id as apartmentId, MAX(f.floorNo) AS floorNo
FROM     dbo.Floor AS f INNER JOIN
                  dbo.Apartment AS a ON f.apartmentId = a.id
GROUP BY a.id
GO
