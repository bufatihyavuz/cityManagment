CREATE procedure Staff_List(
@SayfaNo int,
@SayfaBasinaSayi int
)
AS
BEGIN
SELECT * 
FROM
Staff
ORDER BY id
OFFSET ((@SayfaNo - 1) * @SayfaBasinaSayi) ROWS
FETCH NEXT @SayfaBasinaSayi ROWS ONLY;
END
GO
