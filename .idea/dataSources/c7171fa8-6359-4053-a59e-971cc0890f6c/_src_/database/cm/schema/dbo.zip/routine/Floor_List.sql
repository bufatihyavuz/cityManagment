create procedure Floor_List(
@SayfaNo int,
@SayfaBasinaSayi int
)
AS
BEGIN
SELECT * 
FROM
Floor
ORDER BY id
OFFSET ((@SayfaNo - 1) * @SayfaBasinaSayi) ROWS
FETCH NEXT @SayfaBasinaSayi ROWS ONLY;
END
GO
