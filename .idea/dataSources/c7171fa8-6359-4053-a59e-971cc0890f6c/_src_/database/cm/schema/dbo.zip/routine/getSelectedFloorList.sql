create procedure getSelectedFloorList(
@apartmentId Integer 
)
as begin
select * from Floor a  where a.apartmentId=@apartmentId
end

--select * from Floor a  where a.apartmentId=56
GO
