create procedure [dbo].[Member_List](
@SayfaNo int,
@SayfaBasinaSayi int
)
AS
BEGIN
SELECT * 
FROM
Member
ORDER BY id
OFFSET ((@SayfaNo - 1) * @SayfaBasinaSayi) ROWS
FETCH NEXT @SayfaBasinaSayi ROWS ONLY;
END

GO
