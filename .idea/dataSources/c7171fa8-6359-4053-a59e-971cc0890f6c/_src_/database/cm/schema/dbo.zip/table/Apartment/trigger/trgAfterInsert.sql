create trigger trgAfterInsert
on  Apartment
after insert
as begin
	declare @id int
	Select @id = id from inserted
	insert into  Floor  (apartmentId,floorNo) values (@id,0)
end
GO
