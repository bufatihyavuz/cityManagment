create procedure getFloorNumber(
@apartmentId Integer
)
AS
BEGIN
select MAX(floorNo) from Floor where apartmentId = @apartmentId;
END
GO
