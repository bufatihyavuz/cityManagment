Create View ViewAparmentMaxFloorNo
As
select a.id, Max(f.floorNo) as floorNo From Floor f
Join Apartment a
	On f.apartmentId = a.id
group by a.id
GO
