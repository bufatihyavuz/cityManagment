create procedure [dbo].[Unit_List](
@SayfaNo int,
@SayfaBasinaSayi int
)
AS
BEGIN
SELECT * 
FROM
Unit
ORDER BY id
OFFSET ((@SayfaNo - 1) * @SayfaBasinaSayi) ROWS
FETCH NEXT @SayfaBasinaSayi ROWS ONLY;
END

GO
